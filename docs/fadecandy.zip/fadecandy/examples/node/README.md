Fadecandy Node.js Examples
==========================

This directory contains examples for Fadecandy written in [Node.js](http://nodejs.org/).

Stable Examples
---------------

* `strip_redblue`
  * An example for LED strips. A fade of blue, white, and red washes across the LEDs.
